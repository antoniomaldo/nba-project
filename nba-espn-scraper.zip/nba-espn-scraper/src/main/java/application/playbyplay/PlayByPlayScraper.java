package application.playbyplay;

import application.boxscore.script.ScriptObject;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.Thread.sleep;


public class PlayByPlayScraper {

    public static void main(String[] args) throws IOException, InterruptedException {
        String boxscoresPath = "C:\\Users\\Antonio\\Documents\\NBA\\data\\espn\\Boxscores";
        List<Integer> yearsToScrape = Arrays.asList(2017, 2018, 2019, 2020, 2021, 2022, 2023);

        for (Integer year : yearsToScrape) {
            List<String> gameIds = new ArrayList<>();

            String yearPath = boxscoresPath + "\\" + year;
            File yearFolder = new File(yearPath);
            ArrayList<File> csvs = new ArrayList<>(Arrays.asList(yearFolder.listFiles()));

            for (File csv : csvs) {
                String csvAbsolutePath = csv.getAbsolutePath();
                String csvId = csvAbsolutePath.replace(yearPath, "").replace("bs", "").replace("\\", "").replace(".csv", "");
                gameIds.add(csvId);
            }

            List<String> idsScraped = new ArrayList<>();

            File pbpYearFolder = new File("C:\\Users\\Antonio\\Documents\\NBA\\data\\espn\\PlayByPlay\\" + year);
            if (pbpYearFolder.exists()) {
                for (File pbpFolder : pbpYearFolder.listFiles()) {
                    String scrapedId = pbpFolder.getAbsolutePath().replace(pbpYearFolder.getAbsolutePath(), "").replace("\\", "").replace("pbp", "").replace(".json","");
                    idsScraped.add(scrapedId);
                }
            }

            for (String id : gameIds) {
                try {
                    if (!idsScraped.contains(id)) {
                        System.out.println(id);
                        String url = "https://www.espn.co.uk/nba/playbyplay/_/gameId/" + id;

                        Document doc = Jsoup.connect(url).get();

                        Elements scripts = doc.select("script");
                        Element script = null;

                        for (Element el : scripts) {
                            if (el.html().contains("window['__espnfitt__']")) {
                                script = el;
                            }
                        }

                        String json = script.html().split("window\\['__espnfitt__'\\]=")[1].replace("};", "}");

                        ObjectMapper objectMapper = new ObjectMapper();
                        objectMapper.registerModule(new Jdk8Module());
                        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
                        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

                        ScriptObject scriptObject = objectMapper.readValue(json, ScriptObject.class);

                        File directory = new File("C:\\Users\\Antonio\\Documents\\NBA\\data\\espn\\PlayByPlay\\" + year);
                        if (!directory.exists()) {
                            directory.mkdirs();
                        }
                        Files.write(Paths.get(directory.getAbsolutePath() + "\\pbp" + id + ".json"), objectMapper.writeValueAsBytes(scriptObject.getPage().getContent().getGamepackage()));
                        sleep(3000);
                    }
                } catch (Exception e) {
                    System.out.println("Error getting data for gameId " + id);
                    sleep(3000);
                }
            }
        }
    }
}
