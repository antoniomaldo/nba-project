package application.boxscore;

public class GameBoxscore {

    private final String gameId;
    private final String date;
    private final String awayTeam;
    private final TeamRecord awayTeamRecord;
    private final QuartersScore awayQuartersScore;

    private final String homeTeam;
    private final TeamRecord homeTeamRecord;
    private final QuartersScore homeQuartersScore;

    public GameBoxscore(String gameId, String date, String awayTeam, TeamRecord awayTeamRecord, QuartersScore awayQuartersScore, String homeTeam, TeamRecord homeTeamRecord, application.boxscore.QuartersScore homeQuartersScore) {
        this.gameId = gameId;
        this.date = date;
        this.awayTeam = awayTeam;
        this.awayTeamRecord = awayTeamRecord;
        this.awayQuartersScore = awayQuartersScore;
        this.homeTeam = homeTeam;
        this.homeTeamRecord = homeTeamRecord;
        this.homeQuartersScore = homeQuartersScore;
    }


    public String getGameId() {
        return gameId;
    }

    public String getDate() {
        return date;
    }

    public String getAwayTeam() {
        return awayTeam;
    }

    public TeamRecord getAwayTeamRecord() {
        return awayTeamRecord;
    }

    public QuartersScore getAwayQuartersScore() {
        return awayQuartersScore;
    }

    public String getHomeTeam() {
        return homeTeam;
    }

    public TeamRecord getHomeTeamRecord() {
        return homeTeamRecord;
    }

    public QuartersScore getHomeQuartersScore() {
        return homeQuartersScore;
    }
}
