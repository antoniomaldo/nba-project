package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import java.util.List;

@AutoValue
@JsonDeserialize(builder = Pbp.Builder.class)

public abstract class Pbp {

    public static Builder builder() {
        return new AutoValue_Pbp.Builder();
    }

    public abstract List<List<Play>> getPlayGrps();


    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return Pbp.builder();
        }

        public abstract Builder playGrps(List<List<Play>> playGrps);


        public abstract Pbp build();

    }
}
