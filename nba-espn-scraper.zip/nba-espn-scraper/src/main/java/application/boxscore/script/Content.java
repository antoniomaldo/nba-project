package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

@AutoValue
@JsonDeserialize(builder = Content.Builder.class)

public abstract class Content {

    public static Builder builder() {
        return new AutoValue_Content.Builder();
    }

    @Nullable
    public abstract GamePackage getGamepackage();
    @Nullable
    public abstract Map<String, List<Events>> getEvents();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return Content.builder();
        }

        public abstract Builder gamepackage(GamePackage gamepackage);

        public abstract Builder events(Map<String, List<Events>> events);

        public abstract Content build();

    }
}
