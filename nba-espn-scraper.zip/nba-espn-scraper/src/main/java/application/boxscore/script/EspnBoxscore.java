package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import java.util.List;
import java.util.Map;

@AutoValue
@JsonDeserialize(builder = EspnBoxscore.Builder.class)

public abstract class EspnBoxscore {

    public static Builder builder() {
        return new AutoValue_EspnBoxscore.Builder();
    }

    public abstract Map<String, String> getTm();
    public abstract List<EspnStats> getStats();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return EspnBoxscore.builder();
        }

        public abstract Builder tm(Map<String, String> tm);
        public abstract Builder stats(List<EspnStats> stats);


        public abstract EspnBoxscore build();

    }
}
