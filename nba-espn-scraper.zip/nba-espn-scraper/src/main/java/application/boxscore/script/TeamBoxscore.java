package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import java.util.List;

@AutoValue
@JsonDeserialize(builder = TeamBoxscore.Builder.class)

public abstract class TeamBoxscore {

    public static Builder builder() {
        return new AutoValue_TeamBoxscore.Builder();
    }

    public abstract List<Tms> getTms();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return TeamBoxscore.builder();
        }

        public abstract Builder tms(List<Tms> tms);


        public abstract TeamBoxscore build();
    }
}
