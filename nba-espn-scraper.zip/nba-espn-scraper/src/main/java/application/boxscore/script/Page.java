package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

@AutoValue
@JsonDeserialize(builder = Page.Builder.class)

public abstract class Page {

    public static Builder builder() {
        return new AutoValue_Page.Builder();
    }

    public abstract Content getContent();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Page.Builder create() {
            return Page.builder();
        }

        public abstract Builder content(Content content);


        public abstract Page build();

    }
}
