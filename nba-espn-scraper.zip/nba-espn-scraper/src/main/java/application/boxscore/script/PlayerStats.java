package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import java.util.List;
import java.util.Map;

@AutoValue
@JsonDeserialize(builder = PlayerStats.Builder.class)

public abstract class PlayerStats {

    public static Builder builder() {
        return new AutoValue_PlayerStats.Builder();
    }

    public abstract Map<String, String> getAthlt();
    public abstract List<String> getStats();
    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return PlayerStats.builder();
        }

        public abstract Builder athlt(Map<String, String> athlt);
        public abstract Builder stats(List<String> stats);


        public abstract PlayerStats build();

    }
}
