package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

@AutoValue
@JsonDeserialize(builder = ScriptObject.Builder.class)

public abstract class ScriptObject {

    public static Builder builder() {
        return new AutoValue_ScriptObject.Builder();
    }

    public abstract Page getPage();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static ScriptObject.Builder create() {
            return ScriptObject.builder();
        }

        public abstract Builder page(Page page);


        public abstract ScriptObject build();

    }
}
