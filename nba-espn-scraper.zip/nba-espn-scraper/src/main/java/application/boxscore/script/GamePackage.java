package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import javax.annotation.Nullable;
import java.util.List;

@AutoValue
@JsonDeserialize(builder = GamePackage.Builder.class)

public abstract class GamePackage {

    public static Builder builder() {
        return new AutoValue_GamePackage.Builder();
    }

    @Nullable
    public abstract List<EspnBoxscore> getBxscr();
    public abstract TeamBoxscore getGmStrp();
    @Nullable
    public abstract Pbp getPbp();
    @Nullable
    public abstract ShtChart getShtChrt();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return GamePackage.builder();
        }

        public abstract Builder bxscr(List<EspnBoxscore> bxscr);
        public abstract Builder gmStrp(TeamBoxscore gmStrp);
        public abstract Builder pbp(Pbp pbp);
        public abstract Builder shtChrt(ShtChart shtChrt);

        public abstract GamePackage build();
    }
}
