package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

@AutoValue
@JsonDeserialize(builder = Play.Builder.class)

public abstract class Play {

    public static Builder builder() {
        return new AutoValue_Play.Builder();
    }

    public abstract String getId();
    @Nullable
    public abstract Map<String, String> getPeriod();
    @Nullable
    public abstract String getText();
    @Nullable
    public abstract Boolean getScoringPlay();
    @Nullable
    public abstract Boolean getShootingPlay();
    @Nullable
    public abstract Map<String, String> getAthlete();
    @Nullable
    public abstract Map<String, String> getCoordinate();
    @Nullable
    public abstract Map<String, String> getType();
    @Nullable
    public abstract String getHomeAway();
    @Nullable
    public abstract String getAwayScore();
    @Nullable
    public abstract String getHomeScore();
    @Nullable
    public abstract Map<String, String> getClock();



    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return Play.builder();
        }

        public abstract Builder id(String id);
        public abstract Builder period(Map<String, String> period);
        public abstract Builder text(String text);
        public abstract Builder homeAway(String homeAway);
        public abstract Builder awayScore(String awayScore);
        public abstract Builder homeScore(String homeScore);
        public abstract Builder clock(Map<String, String> clock);

        public abstract Builder scoringPlay(Boolean scoringPlay);
        public abstract Builder shootingPlay(Boolean shootingPlay);
        public abstract Builder athlete(Map<String, String> athlete);
        public abstract Builder coordinate(Map<String, String> coordinate);
        public abstract Builder type(Map<String, String> type);

        public abstract Play build();

    }
}
