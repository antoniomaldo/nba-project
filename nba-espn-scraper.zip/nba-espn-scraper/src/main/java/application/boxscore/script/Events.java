package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import java.util.List;
import java.util.Map;

@AutoValue
@JsonDeserialize(builder = Events.Builder.class)

public abstract class Events {

    public static Builder builder() {
        return new AutoValue_Events.Builder();
    }

    public abstract String getId();


    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return Events.builder();
        }

        public abstract Builder id(String id);


        public abstract Events build();

    }
}
