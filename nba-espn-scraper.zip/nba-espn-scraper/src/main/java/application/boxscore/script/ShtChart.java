package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

@AutoValue
@JsonDeserialize(builder = ShtChart.Builder.class)

public abstract class ShtChart {

    public static Builder builder() {
        return new AutoValue_ShtChart.Builder();
    }

    public abstract List<Play> getPlays();




    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return ShtChart.builder();
        }

        public abstract Builder plays(List<Play> plays);


        public abstract ShtChart build();

    }
}
