package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import java.util.List;

@AutoValue
@JsonDeserialize(builder = PlayGroup.Builder.class)

public abstract class PlayGroup {

    public static Builder builder() {
        return new AutoValue_PlayGroup.Builder();
    }

    public abstract List<Play> getPlayGrps();


    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return PlayGroup.builder();
        }

        public abstract Builder playGrps(List<Play> playGrps);


        public abstract PlayGroup build();

    }
}
