package application.boxscore.script;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;

import java.util.List;
import java.util.Map;

@AutoValue
@JsonDeserialize(builder = Tms.Builder.class)

public abstract class Tms {

    public static Builder builder() {
        return new AutoValue_Tms.Builder();
    }

    public abstract String getAbbrev();
    public abstract String getScore();
    public abstract boolean getIsHome();
    public abstract List<Map<String, String>> getLinescores();
    public abstract List<Map<String, String>> getRecords();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")

    public abstract static class Builder {
        @JsonCreator
        private static Builder create() {
            return Tms.builder();
        }

        public abstract Builder abbrev(String abbrev);
        public abstract Builder score(String score);
        public abstract Builder isHome(boolean isHome);
        public abstract Builder linescores(List<Map<String, String>> linesscores);
        public abstract Builder records(List<Map<String, String>> records);


        public abstract Tms build();
    }
}
