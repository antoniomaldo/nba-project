package application.boxscore;

import org.jsoup.select.Elements;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PlayerBuilder {

    public static PlayerInfo getPlayerInfo(Elements playerData, String teamName, int isStarter) {

        Elements playerElements = playerData.select("td.name").get(0).children();

        String playerName = playerElements.select("span.abbr").text();
        String playerUrl = playerElements.attr("href");

        String playerId = extractPlayerId(playerUrl);

        String position = playerElements.select("span.position").text();
        String min = playerData.select("td.min").text();

        String fg = playerData.select("td.fg").text();
        String[] splitFg = fg.split("-");

        String threePt = playerData.select("td.3pt").text();
        String[] splitThreePts = threePt.split("-");

        String ft = playerData.select("td.ft").text();
        String[] splitFT = ft.split("-");

        String oreb = playerData.select("td.oreb").text();
        String dreb = playerData.select("td.dreb").text();
        String reb = playerData.select("td.reb").text();
        String ast = playerData.select("td.ast").text();
        String stl = playerData.select("td.stl").text();
        String blk = playerData.select("td.blk").text();
        String to = playerData.select("td.to").text();
        String pf = playerData.select("td.pf").text();
        String plusminus = playerData.select("td.plusminus").text();
        String pts = playerData.select("td.pts").text();

        return new PlayerInfo(playerId, teamName, isStarter, //
                playerName, position, min,//
                splitFg[0], splitFg[1],
                splitThreePts[0], splitThreePts[1],
                splitFT[0], splitFT[1],
                oreb, dreb, reb,
                ast, stl, blk, to, pf, plusminus, pts);
    }

    private static String extractPlayerId(String playerName) {
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(playerName);
        if(m.find()){
            return m.group();
        }else{
            return "";
        }
    }
}
