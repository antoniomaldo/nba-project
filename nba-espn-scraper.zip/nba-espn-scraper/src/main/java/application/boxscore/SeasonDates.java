package application.boxscore;

import java.time.LocalDate;

public class SeasonDates {

    private final LocalDate seasonStart;
    private final LocalDate seasonEnd;


    public SeasonDates(int startYear, int startMonth, int startDay, int endMonth, int endDay) {
        this.seasonStart = LocalDate.of(startYear, startMonth, startDay);
        this.seasonEnd = LocalDate.of(startYear + 1, endMonth, endDay);
    }

    public LocalDate getSeasonStart() {
        return seasonStart;
    }

    public LocalDate getSeasonEnd() {
        return seasonEnd;
    }
}
