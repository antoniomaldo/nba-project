package application.boxscore;

public class QuartersScore {
    private final String firstQuarter;
    private final String secondQuarter;
    private final String thirdQuarter;
    private final String fourthQuarter;
    private final String finalScore;

    public QuartersScore(String firstQuarter, String secondQuarter, String thirdQuarter, String fourthQuarter, String finalScore) {
        this.firstQuarter = firstQuarter;
        this.secondQuarter = secondQuarter;
        this.thirdQuarter = thirdQuarter;
        this.fourthQuarter = fourthQuarter;
        this.finalScore = finalScore;
    }

    public String getFirstQuarter() {
        return firstQuarter;
    }

    public String getSecondQuarter() {
        return secondQuarter;
    }

    public String getThirdQuarter() {
        return thirdQuarter;
    }

    public String getFourthQuarter() {
        return fourthQuarter;
    }

    public String getFinalScore() {
        return finalScore;
    }
}