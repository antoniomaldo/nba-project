package application.boxscore;

public class PlayerInfo {

    private final String playerId;
    private final String teamName;
    private final int starter;
    private final String name;
    private final String position;
    private final String min;
    private final String fgMade;
    private final String fgAttempted;
    private final String threePtMade;
    private final String threePtAttempted;
    private final String ftMade;
    private final String ftAttempted;
    private final String ofRebounds;
    private final String dfRebounds;
    private final String rebounds;
    private final String assists;
    private final String steals;
    private final String blocks;
    private final String turnovers;
    private final String fouls;
    private final String plusMinus;
    private final String points;


    public PlayerInfo(String playerId, String teamName, int starter, String name, String position, String min, String fgMade, String fgAttempted, String threePtMade, String threePtAttempted, String ftMade, String ftAttempted, String ofRebounds, String dfRebounds, String rebounds, String assists, String steals, String blocks, String turnovers, String fouls, String plusMinus, String points) {
        this.playerId = playerId;
        this.teamName = teamName;
        this.starter = starter;
        this.name = name;
        this.position = position;
        this.min = min;
        this.fgMade = fgMade;
        this.fgAttempted = fgAttempted;
        this.threePtMade = threePtMade;
        this.threePtAttempted = threePtAttempted;
        this.ftMade = ftMade;
        this.ftAttempted = ftAttempted;
        this.ofRebounds = ofRebounds;
        this.dfRebounds = dfRebounds;
        this.rebounds = rebounds;
        this.assists = assists;
        this.steals = steals;
        this.blocks = blocks;
        this.turnovers = turnovers;
        this.fouls = fouls;
        this.plusMinus = plusMinus;
        this.points = points;
    }

    public String getPlayerId() {
        return playerId;
    }

    public String getTeamName() {
        return teamName;
    }

    public int getStarter() {
        return starter;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public String getMin() {
        return min;
    }

    public String getFgMade() {
        return fgMade;
    }

    public String getFgAttempted() {
        return fgAttempted;
    }

    public String getThreePtMade() {
        return threePtMade;
    }

    public String getThreePtAttempted() {
        return threePtAttempted;
    }

    public String getFtMade() {
        return ftMade;
    }

    public String getFtAttempted() {
        return ftAttempted;
    }

    public String getOfRebounds() {
        return ofRebounds;
    }

    public String getDfRebounds() {
        return dfRebounds;
    }

    public String getRebounds() {
        return rebounds;
    }

    public String getAssists() {
        return assists;
    }

    public String getSteals() {
        return steals;
    }

    public String getBlocks() {
        return blocks;
    }

    public String getTurnovers() {
        return turnovers;
    }

    public String getFouls() {
        return fouls;
    }

    public String getPlusMinus() {
        return plusMinus;
    }

    public String getPoints() {
        return points;
    }
}
