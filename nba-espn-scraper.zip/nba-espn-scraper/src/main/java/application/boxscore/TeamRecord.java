package application.boxscore;

public class TeamRecord {

    private final String overralRecord;
    private final String venueRecord;

    public TeamRecord(String overralRecord, String venueRecord) {
        this.overralRecord = overralRecord;
        this.venueRecord = venueRecord;
    }

    public String getOverralRecord() {
        return overralRecord;
    }

    public String getVenueRecord() {
        return venueRecord;
    }
}