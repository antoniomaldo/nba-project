package application.boxscore;


import static java.lang.Thread.sleep;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

import application.boxscore.script.*;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.opencsv.CSVWriter;
import db.DatabaseHandler;
import org.apache.commons.collections.map.HashedMap;
import org.joda.time.DateTime;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Application {

    private static final DatabaseHandler DATABASE_HANDLER = new DatabaseHandler();

    private static final String BOXSCORE_URL = "http://www.espn.co.uk/nba/boxscore?gameId=";

    private static final String[] GAME_BOXSCORE_HEADER = {"GameId", "Date", "AwayTeam", "Away Ov Record", "Away Record away", "Away 1Q Score", "Away 2Q Score", "Away 3Q Score", "Away 4Q Score", "Away Final Score", "HomeTeam", "Home Ov Record", "Home Record home", "Home 1Q Score", "Home 2Q Score", "Home 3Q Score", "Home 4Q Score", "Home Final Score"};
    private static final String[] PLAYERS_HEADER = {"GameId", "PlayerId", "Team", "Name", "Position", "Starter", "Min", "Fg Made", "Fg Attempted", "Three Made", "Three Attempted", "FT Made", "FT Attempted", "Offensive Rebound", "Defensive Rebound", "Total Rebounds", "Assists", "Steals", "Blocks", "Turnovers", "Personal Fouls", "Plus Minus", "Points"};

    private static final boolean HOME_LAPTOP = true;

    public static final String BASE_CSV_DIR = HOME_LAPTOP ? "C:\\Users\\Antonio\\Documents\\NBA\\data\\espn" : "C:\\Users\\aostios\\Documents\\NBA\\data\\espn";

    private static final Map<Integer, SeasonDates> SEASON_DATES_MAP = initializeMap();

    public static void main(String[] args) throws InterruptedException {

        List<Integer> yearsToScrape = Arrays.asList(2024);

        for (int seasonYear : yearsToScrape) {
            String BOXSCORE_CSV_LOCATION = BASE_CSV_DIR + "\\Boxscores\\"+ seasonYear + "\\";
            String PLAYERS_CSV_LOCATION = BASE_CSV_DIR + "\\Players\\"+  seasonYear + "\\";

            for (int counter = 0; counter <= 0; counter++) {
                File file = new File(BOXSCORE_CSV_LOCATION);
                ArrayList<File> listFiles = new ArrayList<>(Arrays.asList(file.listFiles()));
                List<String>  gameIdsScraped = listFiles.stream().map(f -> extractInteger(f)).collect(Collectors.toList());

                SeasonDates seasonDates = SEASON_DATES_MAP.get(seasonYear);

                LocalDate seasonStart = seasonDates.getSeasonStart();
                LocalDate seasonEnd = seasonDates.getSeasonEnd();

                for (LocalDate dateToScrape = seasonStart; !dateToScrape.isAfter(seasonEnd) && dateToScrape.atStartOfDay().toInstant(ZoneOffset.UTC).getEpochSecond() * 1000 <= DateTime.now().getMillis(); dateToScrape = dateToScrape.plusDays(1)) {
                        sleep(1000);

                        String date = dateToScrape.toString().replace("-", "");
                        System.out.println(date);

                        try {
                            List<String> refs = getIdsForDay("http://www.espn.com/nba/schedule/_/date/",date);

                            for (String gameId : refs) {
                                if (!gameIdsScraped.contains(gameId)) {
                                    try {
                                        scrapeGameForId(gameId, date, BOXSCORE_CSV_LOCATION, PLAYERS_CSV_LOCATION);
                                        System.out.println("GameId scraped: " + gameId);
                                        gameIdsScraped.add(gameId);
                                    } catch (Exception e) {
                                        System.out.println("There was an error when getting the data from game: " + gameId);
                                    }
                                }
                            }
                        } catch (Exception e) {
//                            e.printStackTrace();
                            System.out.println("There was an error when getting the data from date: " + dateToScrape.toString());
                        }
                    }
                }
            }
    }

    private static List<String> getIdsForDay(String s, String date) throws IOException {
        Document doc = Jsoup.connect(s + date).get();

        Elements scripts = doc.select("script");
        Element script = null;

        for (Element el : scripts) {
            if (el.html().contains("window['__espnfitt__']")) {
                script = el;
            }
        }

//        String json = script.html().replace("window['__espnfitt__']=", "").replace("};", "}");
        String json= script.html().split("window\\['__espnfitt__'\\]=")[1].replace("};", "}");

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        ScriptObject scriptObject = objectMapper.readValue(json, ScriptObject.class);

        List<Events> events = scriptObject.getPage().getContent().getEvents().get(date);
        return events.stream().map(e->e.getId()).collect(Collectors.toList());
    }

    private static String extractInteger(File file) {
        return file.getName().replace("bs", "").replace(".csv", "");
    }

    private static void scrapeGameForId(String gameID, String date, String boxscoreCsvLocation, String playersCsvLocation) throws IOException {
        Document doc = Jsoup.connect(BOXSCORE_URL + gameID).get();

        Elements scripts = doc.select("script");
        Element script = null;

        for (Element el : scripts) {
            if (el.html().contains("window['__espnfitt__']")) {
                script = el;
            }
        }

        String json= script.html().split("window\\['__espnfitt__'\\]=")[1].replace("};", "}");

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        ScriptObject scriptObject = objectMapper.readValue(json, ScriptObject.class);

        List<EspnBoxscore> bxscr = scriptObject.getPage().getContent().getGamepackage().getBxscr();

        EspnBoxscore awayBoxscore = bxscr.get(0);
        EspnBoxscore homeBoxscore = bxscr.get(1);

        List<PlayerInfo> awayTeamPlayers = buildAwayTeamPlayers(awayBoxscore);
        List<PlayerInfo> homeTeamPlayers = buildAwayTeamPlayers(homeBoxscore);

        TeamBoxscore gmStrp = scriptObject.getPage().getContent().getGamepackage().getGmStrp();

        Tms homeTms = gmStrp.getTms().stream().filter(t -> t.getIsHome()).findFirst().get();
        Tms awayTms = gmStrp.getTms().stream().filter(t -> !t.getIsHome()).findFirst().get();


        GameBoxscore gameBoxscore = getBoxScoreInfo(gameID, date,homeTms, awayTms);

        awayTeamPlayers.addAll(homeTeamPlayers);

        generateBoxScoreCsv(gameBoxscore, boxscoreCsvLocation);
        generatePlayersCsv(awayTeamPlayers, gameID, playersCsvLocation);
    }

    private static List<PlayerInfo> buildAwayTeamPlayers(EspnBoxscore teamBoxscore) {
        List<EspnStats> stats = teamBoxscore.getStats();
        String teamname = teamBoxscore.getTm().get("abbrev");
        EspnStats starters = stats.get(0);
        EspnStats bench = stats.get(1);
        List<PlayerInfo> list = new ArrayList<>();

        for (PlayerStats playerStats : starters.getAthlts()) {
            List<String> playerBoxscore = playerStats.getStats();

            try {
                String playerId = playerStats.getAthlt().get("id");
                String playerName = playerStats.getAthlt().get("shrtNm");
                String position = playerStats.getAthlt().get("pos");

                String[] fieldGoals = playerBoxscore.get(1).split("-");
                String[] threePointers = playerBoxscore.get(2).split("-");
                String[] freeThrows = playerBoxscore.get(3).split("-");

                PlayerInfo playerInfo = new PlayerInfo(playerId, teamname, 1, playerName, position, playerBoxscore.get(0), //
                        fieldGoals[0], //
                        fieldGoals[1], //
                        threePointers[0], //
                        threePointers[1], //
                        freeThrows[0], //
                        freeThrows[1], //
                        playerBoxscore.get(4), //
                        playerBoxscore.get(5), //
                        playerBoxscore.get(6), //
                        playerBoxscore.get(7), //
                        playerBoxscore.get(8), //
                        playerBoxscore.get(9), //
                        playerBoxscore.get(10), //
                        playerBoxscore.get(11), //
                        playerBoxscore.get(12), //
                        playerBoxscore.get(13));
                list.add(playerInfo);
            }catch (Exception e){

            }
        }

        for (PlayerStats playerStats : bench.getAthlts()) {
            List<String> playerBoxscore = playerStats.getStats();
            String playerId = playerStats.getAthlt().get("id");
            String playerName = playerStats.getAthlt().get("shrtNm");
            String position = playerStats.getAthlt().get("pos");
            position = position == null ? "" : position;

            if (playerBoxscore.size() > 0 && !playerBoxscore.get(0).contains("-")) {
                try {


                    String[] fieldGoals = playerBoxscore.get(1).split("-");
                    String[] threePointers = playerBoxscore.get(2).split("-");
                    String[] freeThrows = playerBoxscore.get(3).split("-");

                    PlayerInfo playerInfo = new PlayerInfo(playerId, teamname, 0, playerName, position, playerBoxscore.get(0), //
                            fieldGoals[0], //
                            fieldGoals[1], //
                            threePointers[0], //
                            threePointers[1], //
                            freeThrows[0], //
                            freeThrows[1], //
                            playerBoxscore.get(4), //
                            playerBoxscore.get(5), //
                            playerBoxscore.get(6), //
                            playerBoxscore.get(7), //
                            playerBoxscore.get(8), //
                            playerBoxscore.get(9), //
                            playerBoxscore.get(10), //
                            playerBoxscore.get(11), //
                            playerBoxscore.get(12), //
                            playerBoxscore.get(13));
                    list.add(playerInfo);
                }catch (Exception e){

                }
            }else{
                PlayerInfo playerInfo = new PlayerInfo(playerId,
                        teamname,
                        0,
                        playerName,
                        position,
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0", //
                        "0");
                list.add(playerInfo);
            }
        }
        return list;
    }

    private static GameBoxscore getBoxScoreInfo(String gameId, String date, Tms homeTms, Tms awayTms) {
        List<Map<String, String>> homeRecords = homeTms.getRecords();
        Optional<Map<String, String>> homeVenueRecords = homeRecords.stream().filter(i -> !i.get("type").equalsIgnoreCase("total")).findFirst();
        Optional<Map<String, String>> homeTotalRecords = homeRecords.stream().filter(i -> i.get("type").equalsIgnoreCase("total")).findFirst();

        List<Map<String, String>> awayRecords = awayTms.getRecords();
        Optional<Map<String, String>> awayVenueRecords = awayRecords.stream().filter(i -> !i.get("type").equalsIgnoreCase("total")).findFirst();
        Optional<Map<String, String>> awayTotalRecords = awayRecords.stream().filter(i -> i.get("type").equalsIgnoreCase("total")).findFirst();

        QuartersScore awayQuartersScore = new QuartersScore(awayTms.getLinescores().get(0).get("displayValue"),
                awayTms.getLinescores().get(1).get("displayValue"),
                awayTms.getLinescores().get(2).get("displayValue"),
                awayTms.getLinescores().get(3).get("displayValue"),
                awayTms.getScore()
        );

        QuartersScore homeQuartersScore = new QuartersScore(homeTms.getLinescores().get(0).get("displayValue"),
                homeTms.getLinescores().get(1).get("displayValue"),
                homeTms.getLinescores().get(2).get("displayValue"),
                homeTms.getLinescores().get(3).get("displayValue"),
                homeTms.getScore()
        );
        TeamRecord homeTeamRecord;
        TeamRecord awayTeamRecord;
        if(homeTotalRecords.isPresent() && homeVenueRecords.isPresent() &&
                awayTotalRecords.isPresent() && awayVenueRecords.isPresent()){
            homeTeamRecord = new TeamRecord(homeTotalRecords.get().get("summary"), homeVenueRecords.get().get("summary"));
            awayTeamRecord = new TeamRecord(awayTotalRecords.get().get("summary"), awayVenueRecords.get().get("summary"));
        }else{
            homeTeamRecord = new TeamRecord("0-0","0-0");
            awayTeamRecord = new TeamRecord("0-0","0-0");
        }

        return new GameBoxscore(gameId, date, awayTms.getAbbrev(),
                awayTeamRecord, //
                awayQuartersScore, //
                homeTms.getAbbrev(), homeTeamRecord, //
                homeQuartersScore //
        );

    }
    private static void generateBoxScoreCsv(GameBoxscore gameBoxscore, String boxScoreLocation) throws IOException {
        String gameId = gameBoxscore.getGameId();
        CSVWriter writer = new CSVWriter(new FileWriter(boxScoreLocation + "bs" + gameId + ".csv"));
        TeamRecord awayTeamRecord = gameBoxscore.getAwayTeamRecord();
        TeamRecord a = null;
        QuartersScore awayQuartersScore = gameBoxscore.getAwayQuartersScore();

        TeamRecord homeTeamRecord = gameBoxscore.getHomeTeamRecord();
        QuartersScore homeQuartersScore = gameBoxscore.getHomeQuartersScore();

        String[] row = {String.valueOf(gameBoxscore.getGameId()), gameBoxscore.getDate(), gameBoxscore.getAwayTeam(), awayTeamRecord.getOverralRecord(), awayTeamRecord.getVenueRecord(), awayQuartersScore.getFirstQuarter(), awayQuartersScore.getSecondQuarter(), awayQuartersScore.getThirdQuarter(), awayQuartersScore.getFourthQuarter(), awayQuartersScore.getFinalScore(), gameBoxscore.getHomeTeam(), homeTeamRecord.getOverralRecord(), homeTeamRecord.getVenueRecord(), homeQuartersScore.getFirstQuarter(), homeQuartersScore.getSecondQuarter(), homeQuartersScore.getThirdQuarter(), homeQuartersScore.getFourthQuarter(), homeQuartersScore.getFinalScore(),

        };

        writer.writeNext(GAME_BOXSCORE_HEADER);
        writer.writeNext(row);
        writer.close();

        //Insert row into database
//
//        DATABASE_HANDLER.insertBoxscore(Integer.parseInt(gameBoxscore.getGameId()), //
//                Integer.parseInt(gameBoxscore.getDate()), //
//                gameBoxscore.getAwayTeam(), //
//                awayTeamRecord.getOverralRecord(),  //
//                awayTeamRecord.getVenueRecord(),  //
//                Integer.parseInt(gameBoxscore.getAwayQuartersScore().getFirstQuarter()), //
//                Integer.parseInt(gameBoxscore.getAwayQuartersScore().getSecondQuarter()), //
//                Integer.parseInt(gameBoxscore.getAwayQuartersScore().getThirdQuarter()), //
//                Integer.parseInt(gameBoxscore.getAwayQuartersScore().getFourthQuarter()), //
//                Integer.parseInt(gameBoxscore.getAwayQuartersScore().getFinalScore()), //
//                gameBoxscore.getHomeTeam(), //
//                homeTeamRecord.getOverralRecord(), //
//                homeTeamRecord.getVenueRecord(), //
//                Integer.parseInt(gameBoxscore.getHomeQuartersScore().getFirstQuarter()), //
//                Integer.parseInt(gameBoxscore.getHomeQuartersScore().getSecondQuarter()), //
//                Integer.parseInt(gameBoxscore.getHomeQuartersScore().getThirdQuarter()), //
//                Integer.parseInt(gameBoxscore.getHomeQuartersScore().getFourthQuarter()), //
//                Integer.parseInt(gameBoxscore.getHomeQuartersScore().getFinalScore()) //
//                );
    }

    private static void generatePlayersCsv(List<PlayerInfo> players, String gameId, String playersCsvLocation) throws IOException {
        CSVWriter writer = new CSVWriter(new FileWriter(playersCsvLocation + "pl" + gameId + ".csv"));
        writer.writeNext(PLAYERS_HEADER);

        for (PlayerInfo player : players) {
            String[] row = {String.valueOf(gameId), player.getPlayerId(), player.getTeamName(), player.getName(), player.getPosition(), String.valueOf(player.getStarter()), player.getMin(), player.getFgMade(), player.getFgAttempted(), player.getThreePtMade(), player.getThreePtAttempted(), player.getFtMade(), player.getFtAttempted(), player.getOfRebounds(), player.getDfRebounds(), player.getRebounds(), player.getAssists(), player.getSteals(), player.getBlocks(), player.getTurnovers(), player.getFouls(), player.getPlusMinus(), player.getPoints()};

            writer.writeNext(row);
        }
        writer.close();
    }


    private static Map<Integer, SeasonDates> initializeMap() {
        Map<Integer, SeasonDates> map = new HashedMap();

        SeasonDates season13 = new SeasonDates(2012, 10, 30, 4, 17);
        SeasonDates season14 = new SeasonDates(2013, 10, 29, 4, 6);
        SeasonDates season15 = new SeasonDates(2014, 10, 28, 4, 15);
        SeasonDates season16 = new SeasonDates(2015, 10, 27, 4, 16);
        SeasonDates season17 = new SeasonDates(2016, 10, 25, 4, 12);
        SeasonDates season18 = new SeasonDates(2017, 10, 17, 4, 11);
        SeasonDates season19 = new SeasonDates(2018, 10, 16, 4, 10);
        SeasonDates season20 = new SeasonDates(2019, 10, 10, 10, 18);
        SeasonDates season21 = new SeasonDates(2020, 12, 21, 10, 18);
        SeasonDates season22 = new SeasonDates(2021, 10, 17, 6, 13);
        SeasonDates season23 = new SeasonDates(2022, 10, 17, 6, 13);
        SeasonDates season24 = new SeasonDates(2023, 10, 23, 6, 13);

        map.put(2013, season13);
        map.put(2014, season14);
        map.put(2015, season15);
        map.put(2016, season16);
        map.put(2017, season17);
        map.put(2018, season18);
        map.put(2019, season19);
        map.put(2020, season20);
        map.put(2021, season21);
        map.put(2022, season22);
        map.put(2023, season23);
        map.put(2024, season24);

        return map;
    }
}

