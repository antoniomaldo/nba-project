package db;

import java.sql.*;

public class DatabaseHandler {

    private static final String DATABASE_URL = "jdbc:mysql://127.0.0.1:3306?useSSL=false";
    private static final String DRIVER_NAME = "com.mysql.jdbc.Driver";

    private Connection openConnection() throws Exception {
        Class.forName(DRIVER_NAME).newInstance();
        Connection conn = DriverManager.getConnection(DATABASE_URL, "root", "password");//, this.user, this.password);
        return conn;
    }

    public ResultSet getQuery(String query) {
        ResultSet results = null;
        try {
            Connection conn = openConnection();
            Statement statement = conn.createStatement();
            results = statement.executeQuery(query);
        } catch (Exception e) {
        }
        return results;
    }

    public void insertBoxscore(int gameid, int date, String awayTeam, String awayovrecord, String awayrecordaway, int away1qscore, int away2qscore, int away3qscore, int away4qscore, int awayfinalscore, String hometeam, String homeovrecord, String homerecordhome, int home1qscore, int home2qscore, int home3qscore, int home4qscore, int homefinalscore) {
        Connection conn = null;
        try {
            conn = openConnection();

//            Statement st = conn.createStatement();

            // the mysql insert statement
            String query = " insert into nba.boxscores"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // create the mysql insert preparedstatement
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setInt(2 - 1, gameid);
            preparedStmt.setInt(3 - 1, date);
            preparedStmt.setString(4 - 1, awayTeam);
            preparedStmt.setString(5 - 1, awayovrecord);
            preparedStmt.setString(6 - 1, awayrecordaway);
            preparedStmt.setInt(7 - 1, away1qscore);
            preparedStmt.setInt(8 - 1, away2qscore);
            preparedStmt.setInt(9 - 1, away3qscore);
            preparedStmt.setInt(10 - 1, away4qscore);
            preparedStmt.setInt(11 - 1, awayfinalscore);
            preparedStmt.setString(12 - 1, hometeam);
            preparedStmt.setString(13 - 1, homeovrecord);
            preparedStmt.setString(14 - 1, homerecordhome);
            preparedStmt.setInt(15 - 1, home1qscore);
            preparedStmt.setInt(16 - 1, home2qscore);
            preparedStmt.setInt(17 - 1, home3qscore);
            preparedStmt.setInt(18 - 1, home4qscore);
            preparedStmt.setInt(19 - 1, homefinalscore);

            preparedStmt.execute();

//            conn.close();           // note that i'm leaving "date_created" out of this insert statement
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void insertPlayers(int gameid, int playerid, String team, String name, String position, int starter, int min, int fgmade, int fgattempted, int
            threemade, int threeattempted, int ftmade, int ftattempted, int offensiverebound, int deffensiverebound, int totalrebounds, int assists, int steals, int blocks, int turnovers, int personalfouls, int plusminus, int points) {
        Connection conn = null;
        try {
            conn = openConnection();

//            Statement st = conn.createStatement();

            // the mysql insert statement
            String query = " insert into nba.players"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // create the mysql insert preparedstatement
            PreparedStatement preparedStmt = conn.prepareStatement(query);
            preparedStmt.setInt(2 - 1, gameid);
            preparedStmt.setInt(3 - 1, playerid);
            preparedStmt.setString(4 - 1, team);
            preparedStmt.setString(5 - 1, name);
            preparedStmt.setString(6 - 1, position);
            preparedStmt.setInt(7 - 1, starter);
            preparedStmt.setInt(8 - 1, min);
            preparedStmt.setInt(9 - 1, fgmade);
            preparedStmt.setInt(10 - 1, fgattempted);
            preparedStmt.setInt(11 - 1, threemade);
            preparedStmt.setInt(12 - 1, threeattempted);
            preparedStmt.setInt(13 - 1, ftmade);
            preparedStmt.setInt(14 - 1, ftattempted);
            preparedStmt.setInt(15 - 1, offensiverebound);
            preparedStmt.setInt(16 - 1, deffensiverebound);
            preparedStmt.setInt(17 - 1, totalrebounds);
            preparedStmt.setInt(18 - 1, assists);
            preparedStmt.setInt(19 - 1, steals);
            preparedStmt.setInt(20 - 1, blocks);
            preparedStmt.setInt(21 - 1, turnovers);
            preparedStmt.setInt(22 - 1, personalfouls);
            preparedStmt.setInt(23 - 1, plusminus);
            preparedStmt.setInt(24 - 1, points);

            preparedStmt.execute();

//            conn.close();           // note that i'm leaving "date_created" out of this insert statement
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}