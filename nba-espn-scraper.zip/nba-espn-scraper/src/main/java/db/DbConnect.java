package db;


import java.sql.ResultSet;
import java.sql.SQLException;

public class DbConnect {

    private static final String QUERY = "SELECT * FROM nba.boxscores;";

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        DatabaseHandler databaseHandler = new DatabaseHandler();

        ResultSet resultSet = databaseHandler.getQuery(QUERY);

        while(resultSet.next()){
            int rownames = resultSet.getInt("rownames");
            int gameid = resultSet.getInt("gameid");
            String date = resultSet.getString("date");
            String awayTeam = resultSet.getString("awayteam");
            String awayovrecord = resultSet.getString("awayovrecord");
            String awayrecordaway = resultSet.getString("awayrecordaway");
            int away1qscore = resultSet.getInt("away1qscore");
            int away2qscore = resultSet.getInt("away2qscore");
            int away3qscore = resultSet.getInt("away3qscore");
            int away4qscore = resultSet.getInt("away4qscore");
            int awayfinalscore = resultSet.getInt("awayfinalscore");
            String hometeam = resultSet.getString("hometeam");
            String homeovrecord = resultSet.getString("homeovrecord");
            String homerecordhome = resultSet.getString("homerecordhome");
            int home1qscore = resultSet.getInt("home1qscore");
            int home2qscore = resultSet.getInt("home2qscore");
            int home3qscore = resultSet.getInt("home3qscore");
            int home4qscore = resultSet.getInt("home4qscore");
            int homefinalscore = resultSet.getInt("homefinalscore");

            int x = 1;
        }


        int x = 1;
    }
}
