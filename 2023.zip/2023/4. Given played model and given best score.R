library(h2o)
library(arm)

allData <- readRDS(file = "C:\\Users\\Antonio\\Documents\\nba-project\\fanduel\\models\\2023\\allData.rds")

allData <- subset(allData, !is.na(allData$ownExpPoints))
allData <- subset(allData, !is.na(allData$pmin))

allData$pmin <- as.numeric(allData$pmin)

allData$resid <- allData$fdPoints - allData$fdPointsPred

binnedplot(allData$fdPointsPred, allData$resid)
binnedplot(allData$fdPointsPred[allData$seasonYear == 2019], allData$resid[allData$seasonYear == 2019])
binnedplot(allData$fdPointsPred[allData$seasonYear == 2020], allData$resid[allData$seasonYear == 2020])
binnedplot(allData$fdPointsPred[allData$seasonYear == 2021], allData$resid[allData$seasonYear == 2021])
binnedplot(allData$fdPointsPred[allData$seasonYear == 2022], allData$resid[allData$seasonYear == 2022])
binnedplot(allData$fdPointsPred[allData$seasonYear == 2023], allData$resid[allData$seasonYear == 2023])

aggMin <- aggregate(pmin ~ GameId + Team, allData, sum)
aggMin <- subset(aggMin, abs(aggMin$pmin - 240)<= 3)

allData$id <- paste0(allData$GameId, "-", allData$Team)
aggMin$id <- paste0(aggMin$GameId, "-", aggMin$Team)

allData <- subset(allData, allData$id %in% aggMin$id)

allData <- subset(allData, allData$fdPoints>0)

allData$expPointsDiff <- abs(allData$ownExpPoints - allData$oppExpPoints)
