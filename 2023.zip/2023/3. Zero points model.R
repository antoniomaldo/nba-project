library(h2o)
library(arm)
source("C:\\Users\\aostios\\Documents\\NBA\\fanduel\\2023\\Utils.R")

allData <- readRDS(file = "C:\\Users\\aostios\\Documents\\NBA\\fanduel\\2023\\allData.rds")

allData <- subset(allData, !is.na(allData$ownExpPoints))
allData <- subset(allData, !is.na(allData$pmin))
allData$pmin <- as.numeric(allData$pmin)

allData <- addColumnsToDf(allData)

allData$zeroPoints <- as.factor(1 * (allData$fdPoints <= 0))
allData$twelvePlayers <- as.factor(allData$numbPlayers)

trainData <- subset(allData, allData$seasonYear %in% c(2020, 2021, 2022) & allData$pmin < 25)
testData <- subset(allData, allData$seasonYear == 2023 & allData$pmin < 25)

# Model

h2o.init()

trainDataH2O <- as.h2o(trainData)
testDataH2O <- as.h2o(testData)

modelDataH2o <- as.h2o(allData)

modelGBM = h2o.gbm(x = c("pmin",
                        # "fdPointsPred",
                        # "teamFdPointsPred",
                         "ownScoreDiff",
                         "numbPlayers"
                   ), y = "zeroPoints",
                   
                   training_frame = trainDataH2O,
                   model_id = "ZeroPointsModel", 
                   seed = 12, 
                   nfolds = 10, 
                   keep_cross_validation_predictions = TRUE, 
                   fold_assignment = "Modulo", 
                   distribution = "bernoulli",
                   max_depth = 2,
                   min_rows = 1000,
                   ntrees = 500)


h2o.download_mojo(modelGBM, path = "C:\\Users\\Antonio\\Documents\\java-projects\\fantasy-model\\src\\main\\resources")


h2o.auc(modelGBM, xval = T) #Mean residual deviance 0.7798013
h2o.auc(modelGBM, xval = F) #Mean residual deviance 0.7790562


testData$predictionsGBM <- as.vector(h2o.predict(modelGBM, testDataH2O)$p1)
testData$residGBM <- 1*(testData$fdPoints == 0) - testData$predictionsGBM

View(testData[c("pmin", 
                "ownExpPoints", 
                "fdPointsPred",
                "teamFdPointsPred", 
                "ownScoreDiff",
                "OwnScore", 
                "OppScore", 
                "numbPlayers",
                "predictionsGBM")])

mean(testData$residGBM)

binnedplot(testData$predictionsGBM, testData$residGBM)
binnedplot(testData$bestPlayerReal, testData$residGBM)
binnedplot(testData$bestPlayerReal - testData$bestPlayerPred, testData$residGBM)

binnedplot(testData$predictionsGBM[testData$ownScoreDiff <0], testData$residGBM[testData$ownScoreDiff < 0])

binnedplot(testData$pmin, testData$residGBM)
binnedplot(testData$fdPointsPred, testData$residGBM)

binnedplot(testData$OwnScore, testData$residGBM)
binnedplot(testData$OppScore, testData$residGBM)

binnedplot(testData$teamFdPointsPred, testData$residGBM)
binnedplot(testData$ownExpPoints, testData$residGBM)
binnedplot(testData$oppExpPoints, testData$residGBM)
binnedplot(abs(testData$expPointsDiff), testData$residGBM)


trainData$predictionsGBM <- as.vector(h2o.predict(modelGBM, trainDataH2O)$p1)
trainData$residGBM <- 1*(trainData$fdPoints == 0) - trainData$predictionsGBM

mean(trainData$residGBM)

binnedplot(trainData$predictionsGBM, trainData$residGBM)
binnedplot(trainData$pmin, trainData$residGBM)
binnedplot(trainData$fdPointsPred, trainData$residGBM)
binnedplot(trainData$ownExpPoints, trainData$residGBM)
binnedplot(trainData$expPointsDiff, trainData$residGBM)
