library(h2o)
library(arm)

allData <- readRDS(file = "C:\\Users\\Antonio\\Documents\\nba-project\\fanduel\\models\\2023\\allData.rds")

allData <- subset(allData, !is.na(allData$ownExpPoints))
allData <- subset(allData, !is.na(allData$pmin))

allData$expPointsDiff <- abs(allData$ownExpPoints - allData$oppExpPoints)

aggMin <- aggregate(pmin ~ GameId + Team, allData, sum)
aggMin <- subset(aggMin, abs(aggMin$pmin - 240) <= 3)

allData$id <- paste0(allData$GameId, "-", allData$Team)
aggMin$id <- paste0(aggMin$GameId, "-", aggMin$Team)

allData <- subset(allData, allData$id %in% aggMin$id)

aggPred <- aggregate(fdPointsPred ~ GameId + Team, allData, sum)
colnames(aggPred)[3] <- "teamFdPointsPred"

allData <- merge(allData, aggPred)

numbPlayers <- aggregate(fdPointsPred ~ GameId + Team, allData, length)
colnames(numbPlayers)[3] <- "numbPlayers"
allData <- merge(allData, numbPlayers)

allData$ownScoreDiff <- allData$OwnScore - allData$ownExpPoints
allData$zeroPoints <- as.factor(1 * (allData$fdPoints <= 0))
allData$twelvePlayers <- as.factor(allData$numbPlayers)

trainData <- subset(allData, allData$seasonYear %in% c(2019, 2020, 2021, 2022))
testData <- subset(allData, allData$seasonYear == 2023)

# Model

h2o.init()

trainDataH2O <- as.h2o(trainData)
testDataH2O <- as.h2o(testData)

modelDataH2o <- as.h2o(allData)

modelGBM = h2o.gbm(x = c("pmin",
                         "ownExpPoints",
                         "fdPointsPred",
                         "teamFdPointsPred",
                         "ownScoreDiff",
                         "OwnScore",
                         "OppScore",
                         "numbPlayers"
                   ), y = "zeroPoints",
                   
                   training_frame = trainDataH2O,
                   model_id = "ZeroPointsModel", 
                   seed = 12, 
                   nfolds = 10, 
                   keep_cross_validation_predictions = TRUE, 
                   fold_assignment = "Modulo", 
                   distribution = "bernoulli",
                   max_depth = 5,
                   min_rows = 500,
                   ntrees = 500)


h2o.download_mojo(modelGBM, path = "C:\\Users\\Antonio\\Documents\\java-projects\\fantasy-model\\src\\main\\resources")


h2o.auc(modelGBM, xval = T) #Mean residual deviance 0.7798013
h2o.auc(modelGBM, xval = F) #Mean residual deviance 0.7790562


testData$predictionsGBM <- as.vector(h2o.predict(modelGBM, testDataH2O)$p1)
testData$residGBM <- 1*(testData$fdPoints == 0) - testData$predictionsGBM

View(testData[c("pmin", 
                "ownExpPoints", 
                "fdPointsPred",
                "teamFdPointsPred", 
                "ownScoreDiff",
                "OwnScore", 
                "OppScore", 
                "numbPlayers",
                "predictionsGBM")])

mean(testData$residGBM)

binnedplot(testData$predictionsGBM, testData$residGBM)
binnedplot(testData$predictionsGBM[testData$ownScoreDiff <0], testData$residGBM[testData$ownScoreDiff < 0])

binnedplot(testData$pmin, testData$residGBM)
binnedplot(testData$numbPlayers, testData$residGBM)

binnedplot(testData$OwnScore, testData$residGBM)
binnedplot(testData$OppScore, testData$residGBM)

binnedplot(testData$teamFdPointsPred, testData$residGBM)
binnedplot(testData$ownExpPoints, testData$residGBM)
binnedplot(testData$oppExpPoints, testData$residGBM)
binnedplot(abs(testData$expPointsDiff), testData$residGBM)


trainData$predictionsGBM <- as.vector(h2o.predict(modelGBM, trainDataH2O)$p1)
trainData$residGBM <- 1*(trainData$fdPoints == 0) - trainData$predictionsGBM

mean(trainData$residGBM)

binnedplot(trainData$predictionsGBM, trainData$residGBM)
binnedplot(trainData$pmin, trainData$residGBM)
binnedplot(trainData$fdPointsPred, trainData$residGBM)
binnedplot(trainData$ownExpPoints, trainData$residGBM)
binnedplot(trainData$expPointsDiff, trainData$residGBM)
