library(sqldf)
library(arm)
library(stringr)
library(zoo)

source("C:\\Users\\Antonio\\Documents\\nba-project\\data\\utils\\Utils.R")
source("C:\\Users\\Antonio\\Documents\\nba-project\\data\\mappings\\mappings-service.R")

boxscores <-  getPlayersForYear(2018)
boxscores <- rbind(boxscores, getPlayersForYear(2019))
boxscores <- rbind(boxscores, getPlayersForYear(2020))
boxscores <- rbind(boxscores, getPlayersForYear(2021))
boxscores <- rbind(boxscores, getPlayersForYear(2022))
boxscores <- rbind(boxscores, getPlayersForYear(2023))

games <- getMatchesForYear(2018)
games <- rbind(games, getMatchesForYear(2019))
games <- rbind(games, getMatchesForYear(2020))
games <- rbind(games, getMatchesForYear(2021))
games <- rbind(games, getMatchesForYear(2022))
games <- rbind(games, getMatchesForYear(2023))

boxscores <- merge(boxscores, games[c("GameId", "HomeTeam", "AwayTeam", "Home.Final.Score", "Away.Final.Score")], by = "GameId")
boxscores$OwnScore <- ifelse(boxscores$Team == boxscores$HomeTeam, boxscores$Home.Final.Score, boxscores$Away.Final.Score)
boxscores$OppScore <- ifelse(boxscores$Team != boxscores$HomeTeam, boxscores$Home.Final.Score, boxscores$Away.Final.Score)

#Get roto preds
minPredsRotowire <- mapMinutesForSeasonForRotogrinders(2019)
minPredsRotowire <- rbind(minPredsRotowire, mapMinutesForSeasonForRotogrinders(2020))
minPredsRotowire <- rbind(minPredsRotowire, mapMinutesForSeasonForRotogrinders(2021))
minPredsRotowire <- rbind(minPredsRotowire, mapMinutesForSeasonForRotogrinders(2022))
minPredsRotowire <- rbind(minPredsRotowire, mapMinutesForSeasonForRotogrinders(2023))

agg <- aggregate(pmin ~ GameId + Team, minPredsRotowire, sum)

minPredsRotowire$resid <- minPredsRotowire$fdPoints - minPredsRotowire$fdPointsPred

binnedplot(minPredsRotowire$fdPointsPred, minPredsRotowire$resid)
binnedplot(as.numeric(minPredsRotowire$MIN), minPredsRotowire$resid)

minPredsRotowire <- minPredsRotowire[c("GameId", "PlayerId", "pmin", "fdPoints", "fdPointsPred")]

#Get odds
odds <- mapSbrDataToEspn(games)

boxscores <- merge(boxscores, minPredsRotowire, by = c("GameId", "PlayerId"), all.x = T)
boxscores <- merge(boxscores, odds[c("GameId", "matchSpread", "totalPoints")], by = c("GameId"), all.x = T)

boxscores$homeExp <- (boxscores$totalPoints - boxscores$matchSpread) / 2
boxscores$awayExp <- (boxscores$totalPoints + boxscores$matchSpread) / 2

boxscores$ownExpPoints <- ifelse(boxscores$Team == boxscores$HomeTeam, boxscores$homeExp, boxscores$awayExp)
boxscores$oppExpPoints <- ifelse(boxscores$Team != boxscores$HomeTeam, boxscores$homeExp, boxscores$awayExp)

saveRDS(boxscores, file = "C:\\Users\\Antonio\\Documents\\nba-project\\fanduel\\models\\2023\\allData.rds")
