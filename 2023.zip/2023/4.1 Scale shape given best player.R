trainData$predictionsGBM <- as.vector(h2o.predict(modelGBM, trainDataH2O))

getScale <- function(df, par){
  return(exp(par[1] * df$predictionsGBM + 
             par[2] * (df$predictionsGBM ^ 2) + 
             par[3] * pmax(0, 20 - df$predictionsGBM)))
}

functionToOptimizeBinom <- function(df){
  df$underProb <- pgamma(df$predictionsGBM, scale = df$scale, shape = df$shape)
  df$wasUnder <- 1 * (df$fdPoints < df$predictionsGBM)
  
  lik = dbinom(df$wasUnder, size = 1, prob = df$underProb)
  lik = pmax(0.01, pmin(0.99, lik))
  return(-1*sum(log(lik)))
}

functionToOptimizeGamma <- function(df){
  return(-1*sum(log(dgamma(df$fdPoints, scale = df$scale, shape = df$shape))))
}

gammaOptimizerFunction <- function(df, par){
  df$scale <- getScale(df, par)
  df$shape = df$predictionsGBM / df$scale
  
  return(functionToOptimizeGamma(df))
}


optimPar <- optim(par = c(1, 0, 0), gammaOptimizerFunction, df = trainData) #173661.7

testData$scale <- getScale(testData, optimPar$par)
testData$shape <-  testData$predictionsGBM / testData$scale

plotForMultiplier <- function(df, multiplier){
  df$overPred <- 1 - pgamma(multiplier * df$predictionsGBM, scale=df$scale, shape = df$shape)
  df$overResid <- 1 * (df$fdPoints > (multiplier * df$predictionsGBM)) - df$overPred
  windows()
  binnedplot(df$predictionsGBM, df$overResid)
}

plotForMultiplier(testData, 1)
plotForMultiplier(testData, 1.1)
plotForMultiplier(testData, 1.2)
plotForMultiplier(testData, 1.5)
plotForMultiplier(testData, 2)
plotForMultiplier(testData, 0.3)
plotForMultiplier(testData, 0.2)


testData$overPred2 <- 1 - pgamma(2 * testData$predictionsGBM, scale=testData$scale, shape = testData$shape)
testData$overResid2 <- 1 * (testData$fdPoints > 2 * testData$predictionsGBM) - testData$overPred2

mean(testData$overResid2)
binnedplot(testData$predictionsGBM, testData$overResid2)
binnedplot(testData$bestPlayerPred, testData$overResid2)

testData$overPred3 <- 1 - pgamma(1.3 * testData$predictionsGBM, scale=testData$scale, shape = testData$shape)
testData$overResid3 <- 1 * (testData$fdPoints > 1.3 * testData$predictionsGBM) - testData$overPred3
binnedplot(testData$bestPlayerPred, testData$overResid3)

mean(testData$overResid3)

binnedplot(testData$predictionsGBM, testData$overResid3)
