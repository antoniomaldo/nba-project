library(h2o)
library(arm)

source("C:\\Users\\aostios\\Documents\\NBA\\fanduel\\2023\\Utils.R")

allData <- readRDS(file = "C:\\Users\\aostios\\Documents\\NBA\\fanduel\\2023\\allData.rds")

allData <- subset(allData, !is.na(allData$ownExpPoints))
allData <- subset(allData, !is.na(allData$pmin))
allData$pmin <- as.numeric(allData$pmin)

allData <- addColumnsToDf(allData)

allData <- subset(allData, allData$fdPoints>0)

#allData <- subset(allData, allData$bestPlayer == 1)

trainData <- subset(allData, allData$seasonYear %in% c(2018, 2019, 2020, 2021, 2022))
testData <- subset(allData, allData$seasonYear == 2023)


# Model

h2o.init()

trainDataH2O <- as.h2o(trainData)
testDataH2O <- as.h2o(testData)

modelDataH2o <- as.h2o(allData)

modelGBM = h2o.gbm(x = c("pmin",
                         "ownExpPoints",
                         "fdPointsPred",
                         "teamFdPointsPred",
                         "ownScoreDiff",
                         "OwnScore",
                         "OppScore"
                         ), y = "fdPoints",

                  training_frame = trainDataH2O,
                  model_id = "GivenNonZeroModel", 
                  seed = 12, 
                  nfolds = 10, 
                  keep_cross_validation_predictions = TRUE, 
                  fold_assignment = "Modulo", 
                  distribution = "gamma",
                  max_depth = 2,
                  min_rows = 500,
                  ntrees = 500)


h2o.download_mojo(modelGBM, path = "C:\\Users\\Antonio\\Documents\\java-projects\\fantasy-model\\src\\main\\resources")


h2o.performance(modelGBM, xval = T) #Mean residual deviance 0.7798013
h2o.performance(modelGBM, xval = F) #Mean residual deviance 0.7790562

h2o.performance(modelGBM, newdata = trainDataH2O) #Mean residual deviance 0.7798013
h2o.performance(modelGBM, newdata = testDataH2O) #Mean residual deviance 0.7790562

testData$predictionsGBM <- as.vector(h2o.predict(modelGBM, testDataH2O))
testData$residGBM <- testData$fdPoints - testData$predictionsGBM

View(testData[c("pmin", 
                "ownExpPoints", 
                "fdPointsPred",
                "teamFdPointsPred", 
                "ownScoreDiff",
                "OwnScore", 
                "OppScore", 
                "predictionsGBM")])

mean(testData$residGBM)

windows()
binnedplot(testData$predictionsGBM, testData$residGBM)
binnedplot(testData$predictionsGBM[testData$ownScoreDiff <0], testData$residGBM[testData$ownScoreDiff < 0])
binnedplot(testData$predictionsGBM[testData$OwnScore >120], testData$residGBM[testData$OwnScore >120])

binnedplot(testData$predictionsGBM[testData$bestPlayer == 1], 
           testData$residGBM[testData$bestPlayer == 1])

binnedplot(testData$pmin, testData$residGBM)
binnedplot(testData$OwnScore, testData$residGBM)
binnedplot(testData$OppScore, testData$residGBM)
binnedplot(testData$numbPlayers, testData$residGBM)

binnedplot(testData$teamFdPointsPred, testData$residGBM)
binnedplot(testData$ownExpPoints, testData$residGBM)
binnedplot(testData$oppExpPoints, testData$residGBM)
binnedplot(abs(testData$expPointsDiff), testData$residGBM)


trainData$predictionsGBM <- as.vector(h2o.predict(modelGBM, trainDataH2O))
trainData$residGBM <- trainData$fdPoints - trainData$predictionsGBM

mean(trainData$residGBM)

binnedplot(trainData$predictionsGBM, trainData$residGBM)
binnedplot(trainData$pmin, trainData$residGBM)
binnedplot(trainData$fdPointsPred, trainData$residGBM)
binnedplot(trainData$ownExpPoints, trainData$residGBM)
binnedplot(trainData$expPointsDiff, trainData$residGBM)

####

trainData$predictionsGBM <- as.vector(h2o.predict(modelGBM, trainDataH2O))

trainData <- subset(trainData, trainData$bestPlayer == 1)
testData <- subset(testData, testData$bestPlayer == 1)

getScale <- function(df, par){
  return(exp(par[1] * df$predictionsGBM + 
               par[2] * (df$predictionsGBM ^ 2) + 
               par[3] * pmax(0, 20 - df$predictionsGBM) + 
               par[4] * log(df$predictionsGBM)))
}

functionToOptimizeBinom <- function(df){
  df$underProb <- pgamma(df$predictionsGBM, scale = df$scale, shape = df$shape)
  df$wasUnder <- 1 * (df$fdPoints < df$predictionsGBM)
  
  lik = dbinom(df$wasUnder, size = 1, prob = df$underProb)
  lik = pmax(0.01, pmin(0.99, lik))
  return(-1*sum(log(lik)))
}

functionToOptimizeGamma <- function(df){
  return(-1*sum(log(dgamma(df$fdPoints, scale = df$scale, shape = df$shape))))
}

gammaOptimizerFunction <- function(df, par){
  df$scale <- getScale(df, par)
  df$shape = df$predictionsGBM / df$scale
  
  return(functionToOptimizeGamma(df))
}


optimPar <- optim(par = c(1, 0, 0, 0), gammaOptimizerFunction, df = trainData) #173661.7

testData$scale <- getScale(testData, optimPar$par)
testData$shape <-  testData$predictionsGBM / testData$scale

plotForMultiplier <- function(df, multiplier){
  df$overPred <- 1 - pgamma(multiplier * df$predictionsGBM, scale=df$scale, shape = df$shape)
  df$overResid <- 1 * (df$fdPoints > (multiplier * df$predictionsGBM)) - df$overPred
  windows()
  binnedplot(df$predictionsGBM, df$overResid)
}

plotForMultiplier(testData, 1)
plotForMultiplier(testData, 1.1)
plotForMultiplier(testData, 1.2)
plotForMultiplier(testData, 1.5)
plotForMultiplier(testData, 2)
plotForMultiplier(testData, 0.3)
plotForMultiplier(testData, 0.2)

optimPar