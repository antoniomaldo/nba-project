addColumnsToDf <- function(df){
  
  totalMins <- aggregate(Min ~ GameId + Team, df, sum)
  totalMins$isOT <- 1 * (totalMins$Min > 242)
  df <- merge(df, totalMins[c("GameId", "Team", "isOT")], by = c("GameId", "Team"))
  
  aggMin <- aggregate(pmin ~ GameId + Team, df, sum)
  aggMin <- subset(aggMin, abs(aggMin$pmin - 240)<= 3)
  
  df$id <- paste0(df$GameId, "-", df$Team)
  aggMin$id <- paste0(aggMin$GameId, "-", aggMin$Team)
  
  df <- subset(df, df$id %in% aggMin$id)
  
  # Best player
  
  bestPlayer <- aggregate(fdPointsPred ~ GameId + Team, df, max)
  colnames(bestPlayer)[3] <- "bestPlayerPred"
  
  df <- merge(df, bestPlayer, by = c("GameId", "Team"))
  
  df$bestPlayer <- 1 * (df$fdPointsPred == df$bestPlayerPred)
  df$bestPlayer[df$GameId == 401161342 & df$PlayerId == 3995] <- 0
  df$bestPlayer[df$GameId == 401161270 & df$PlayerId == 4278129] <- 0
  
  agg <- aggregate(bestPlayer ~ GameId + Team, df, sum)
  
  bestPlayers <- subset(df[c("GameId", "Team", "fdPoints")], df$bestPlayer == 1)
  colnames(bestPlayers)[3] <- "bestPlayerReal"
  
  df <- merge(df, bestPlayers, by = c("GameId", "Team"))
  
  aggPred <- aggregate(fdPointsPred ~ GameId + Team, df, sum)
  colnames(aggPred)[3] <- "teamFdPointsPred"
  df <- merge(df, aggPred)
  
  numbPlayers <- aggregate(fdPointsPred ~ GameId + Team, df, length)
  colnames(numbPlayers)[3] <- "numbPlayers"
  df <- merge(df, numbPlayers)
  df <- subset(df, df$numbPlayers >= 8)
  
  df$expPointsDiff <- abs(df$ownExpPoints - df$oppExpPoints)
  
  df$ownScoreDiff <- df$OwnScore - df$ownExpPoints
  return(df)
}


